package com.abc.handoff;


import com.abc.pp.stringhandoff.*;
import com.programix.thread.*;

public class StringHandoffImpl implements StringHandoff {
    private String message;
    private boolean isMessageAvailable = false;
    private boolean isShutdown = false;
    private boolean isPasserWaiting = false;
    private boolean isReceiverWaiting = false;

    @Override
    public synchronized void pass(String msg, long msTimeout)
            throws InterruptedException, TimedOutException, ShutdownException, IllegalStateException {
        if (msTimeout < 0) { msTimeout = 0; }
        if (isShutdown) { throw new ShutdownException(); }
        if (isPasserWaiting) { throw new IllegalStateException("Another thread is already waiting to pass"); }
        isPasserWaiting = true;

        long startTime = System.currentTimeMillis();
        try {
            while (isMessageAvailable) {
                if (isShutdown) { throw new ShutdownException(); }
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (msTimeout > 0 && elapsedTime >= msTimeout) {
                    isPasserWaiting = false;
                    throw new TimedOutException();
                }
                wait(msTimeout == 0 ? 0 : msTimeout - elapsedTime);
            }
            this.message = msg;
            this.isMessageAvailable = true;
            notifyAll();

            while (isMessageAvailable) {
                if (isShutdown) { throw new ShutdownException(); }
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (msTimeout > 0 && elapsedTime >= msTimeout) {
                    this.message = null;
                    this.isMessageAvailable = false;
                    isPasserWaiting = false;
                    throw new TimedOutException();
                }
                wait(msTimeout == 0 ? 0 : msTimeout - elapsedTime);
            }
        } catch (InterruptedException e) {
            this.message = null;
            this.isMessageAvailable = false;
            throw e;
        } finally {
            isPasserWaiting = false;
        }
    }



    @Override
    public synchronized void pass(String msg) throws InterruptedException, ShutdownException, IllegalStateException {
        pass(msg, 0L);
    }

    @Override
    public synchronized String receive(long msTimeout)
            throws InterruptedException, TimedOutException, ShutdownException, IllegalStateException {
        if (msTimeout < 0) { msTimeout = 0; }
        if (isShutdown) { throw new ShutdownException(); }
        if (isReceiverWaiting) { throw new IllegalStateException("Another thread is already waiting to receive"); }
        isReceiverWaiting = true;

        long startTime = System.currentTimeMillis();
        try {
            while (!isMessageAvailable) {
                if (isShutdown) { throw new ShutdownException(); }
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (msTimeout > 0 && elapsedTime >= msTimeout) { throw new TimedOutException(); }
                wait(msTimeout == 0 ? 0 : msTimeout - elapsedTime);
            }
            String result = this.message;
            this.message = null;
            this.isMessageAvailable = false;
            notifyAll();
            return result;
        } finally {
            isReceiverWaiting = false;
        }
    }

    @Override
    public synchronized String receive() throws InterruptedException, ShutdownException, IllegalStateException {
        return receive(0L);
    }

    @Override
    public synchronized void shutdown() {
        this.isShutdown = true;
        notifyAll();
    }

    @Override
    public Object getLockObject() {
        return this;
    }
}
